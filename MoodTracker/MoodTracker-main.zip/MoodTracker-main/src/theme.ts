export const theme = {
  colorPurple: '#454C73',
  colorLavender: '#87677B',
  colorBlue: '#1D84B5',
  colorGrey: '#8E9AAF',
  colorWhite: '#fff',

  fontFamilyBold: 'Kalam-Bold',
  fontFamilyRegular: 'Kalam-Regular',
  fontFamilyLight: 'Kalam-Light',
};

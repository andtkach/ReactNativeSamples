module.exports = {
  singleQuote: true,
  trailingComma: 'all',
  printWidth: 100,
  bracketSpacing: false,
  arrowParens: 'avoid',
};